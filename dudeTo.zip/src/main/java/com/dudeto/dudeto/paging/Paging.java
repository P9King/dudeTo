package com.dudeto.dudeto.paging;


import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class Paging {
    public int showListCount = 0; // 글 개수
    public int pageSize = 0;  // 페이지 개수
    public Long totalBoardCount = 0L; // 총 글 개수
    public int curPage = 0; // 현재 페이지로 쓸 변수

    public Paging() {
    }

    public Paging(int showListCount, int pageSize, Long writing_Count, int curPage) {
        super();
        this.showListCount = showListCount;
        this.pageSize = pageSize;
        this.totalBoardCount = writing_Count;
        this.curPage = curPage;
    }

    //총 필요한 페이지 개수
    public Long getTotalPage_Count()
    {
        return ( (totalBoardCount - 1) / showListCount) + 1;
    }

    //페이지 시작 숫자
    public int getPage_Start()
    {
        return ( ( curPage - 1 ) / pageSize) * pageSize + 1;
    }

    //페이지 마지막 숫자
    public Long getPage_End()
    {
        return Math.min( getPage_Start() + pageSize - 1 , getTotalPage_Count() );
    }

    //Pre 표시 여부
    public boolean isPre()
    {
        return getPage_Start() != 1;
    }

    //Next 표시 여부
    public boolean isNext()
    {
        return getPage_End() < getTotalPage_Count();
    }

    //글 범위 시작 번호
    public int getWriting_Start()
    {
        return getWriting_End() - showListCount + 1;
    }

    //글 범위 끝 번호
    public int getWriting_End()
    {
        return curPage * showListCount;
    }

    //밑에는 하나의 예시
  /*  public static void main(String[] args) {

        // 여러가지 매개변수로 테스트 해보시기 바랍니다.
        Paging pg = new Paging(5, 5, 26 , 6 );
        // 총 글의 갯수는 select count(*) from board 하면 나오겠죠 ,
        //현재 보고 있는 페이지 번호는 Default 1, 그리고 밑에 페이징에서 링크 걸린 i가 현재 페이지가 됩니다.

        //Paging pg = new Paging(한 화면에 보여질 글 수 , 페이지 분할 수 , 총 글의 갯수  , 현재 보고 있는 페이지 번호  );

        System.out.println("총 페이지 개수 : "+pg.getPage_Count());
        System.out.println("페이지 시작 숫자  : "+pg.getPage_Start());
        System.out.println("페이지 마지막 숫자  : "+pg.getPage_End());
        System.out.println("Pre 표시 여부  : "+pg.isPre());
        System.out.println("Next 표시 여부   : "+pg.isNext());
        System.out.println("글 범위 시작 번호   : "+pg.getWriting_Start());
        System.out.println("글 범위 끝 번호   : "+pg.getWriting_End());

        System.out.println("select * from board where no between "+pg.getWriting_Start()+" and "+pg.getWriting_End());
        // 이 셀렉트 결과를 화면에 뿌린 후에


        // 밑에서 페이징을 하면 되겠죠? 이거에 링크를 걸고 i가 현재 페이지 번호로서 링크가 걸리게 되겠죠?
        if(pg.isPre())
            System.out.print(" Pre ");
        for(int i = pg.getPage_Start(); i <= pg.getPage_End();i++)
        {
            System.out.print(" "+i+" ");
        }
        if(pg.isNext())
            System.out.print(" Next ");

        // 이런 페이징 클래스를 작성하여 사용하는 것이 여러모로 편리합니다. ~ ㅋㅋ

    }*/

}
