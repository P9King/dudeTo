package com.dudeto.dudeto;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DudeToApplicationTests {

    @Test
    void contextLoads() {
    }

}
