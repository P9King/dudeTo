package com.dudeto.dudeto.service;

class BoardServiceImplTest {
    public static void writeBoard() {
        String projectPath = System.getProperty("user.dir");
        System.out.println("projectPath = " + projectPath);
    }


   static void  main(String[] args){
       writeBoard();
    }
}